appManagerMSF.controller('dataimportController', ["$scope",'$filter', function($scope, $filter) {
		var $translate = $filter('translate');
	
}]);