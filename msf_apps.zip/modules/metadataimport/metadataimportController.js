appManagerMSF.controller('metadataimportController', ["$scope",'$filter', function($scope, $filter) {
		var $translate = $filter('translate');
	
}]);