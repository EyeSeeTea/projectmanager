appManagerMSF.controller('dataexportController', ["$scope",'$filter', function($scope, $filter) {
		var $translate = $filter('translate');
}]);